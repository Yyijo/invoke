# Virtual Queue 

## A Software Development project.

This system is meant to make restaurant serve their clients effectively and quickly without wasting time.


### Engineered by invoke.
